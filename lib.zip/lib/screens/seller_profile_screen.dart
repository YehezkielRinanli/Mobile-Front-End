import 'package:flutter/material.dart';
import 'package:profile_penjual/core/constants/app_assets.dart';
import 'package:profile_penjual/core/constants/app_spacing.dart';
import 'package:profile_penjual/core/constants/app_strings.dart';
import 'package:profile_penjual/data/product_data.dart';
import 'package:profile_penjual/widgets/common/section_title.dart';
import 'package:profile_penjual/widgets/common/trusted_badge.dart';
import 'package:profile_penjual/widgets/product/product_grid.dart';
import 'package:profile_penjual/widgets/profile/rating_info.dart';
import 'package:profile_penjual/widgets/profile/seller_header.dart';
import 'package:profile_penjual/widgets/profile/seller_story.dart';

class SellerProfilePage extends StatelessWidget {
  const SellerProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: colors.primary,
        foregroundColor: colors.onPrimary,
        centerTitle: true,
        leading: Padding(
          padding: const EdgeInsets.all(AppSpacing.sm),
          child: Container(
            width: 40,
            height: 40,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: colors.onPrimary,
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.arrow_back_ios_new,
              size: 18,
              color: colors.primary,
            ),
          ),
        ),
        title: const Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.eco),
            SizedBox(width: AppSpacing.sm),
            Text(AppStrings.appName),
          ],
        ),
      ),
      body: ListView(
        children: [
          const SizedBox(height: AppSpacing.lg),
          Align(
            alignment: Alignment.center,
            child: Text(
              AppStrings.pageTitle,
              style: textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SellerHeader(
            imagePath: AppAssets.avatarSiti,
            name: AppStrings.sellerName,
            shopName: AppStrings.shopName,
            email: AppStrings.email,
            phone: AppStrings.phone,
            city: AppStrings.city,
          ),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: AppSpacing.lg),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                RatingInfo(
                  rating: AppStrings.rating,
                  reviewCount: AppStrings.reviewCount,
                ),
                SizedBox(height: AppSpacing.sm),
                TrustedBadge(label: AppStrings.trustedLabel),
              ],
            ),
          ),
          const SellerStory(
            title: AppStrings.storyTitle,
            story: AppStrings.storyText,
          ),
          const SectionTitle(title: AppStrings.catalogTitle),
          const ProductGrid(
            products: productList,
            ecoLabel: AppStrings.ecoLabel,
          ),
        ],
      ),
    );
  }
}