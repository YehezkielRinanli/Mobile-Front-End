import 'package:flutter/material.dart';
import 'package:profile_penjual/core/constants/app_breakpoints.dart';
import 'package:profile_penjual/core/constants/app_spacing.dart';
import 'package:profile_penjual/widgets/profile/contact_label.dart';
import 'package:profile_penjual/widgets/profile/seller_avatar.dart';
import 'package:profile_penjual/widgets/profile/shop_tag.dart';

class SellerHeader extends StatelessWidget {
  final String imagePath;
  final String name;
  final String shopName;
  final String email;
  final String phone;
  final String city;

  const SellerHeader({
    super.key,
    required this.imagePath,
    required this.name,
    required this.shopName,
    required this.email,
    required this.phone,
    required this.city,
  });

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;

    final screenWidth = MediaQuery.sizeOf(context).width;
    final isWide = screenWidth >= AppBreakpoints.wide;
    final avatarRadius = isWide ? 64.0 : 40.0;

    final emailLabel = ContactLabel(
      icon: Icons.email,
      label: 'Email',
      value: email,
    );
    final phoneLabel = ContactLabel(
      icon: Icons.phone,
      label: 'No. Telepon',
      value: phone,
    );
    final cityLabel = ContactLabel(
      icon: Icons.location_on,
      label: 'Kota',
      value: city,
    );

    return Container(
      margin: const EdgeInsets.all(AppSpacing.lg),
      padding: const EdgeInsets.all(AppSpacing.lg),
      decoration: BoxDecoration(
        color: colors.surfaceContainerLowest,
        borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              SellerAvatar(imagePath: imagePath, radius: avatarRadius),
              const SizedBox(width: AppSpacing.lg),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      style: textTheme.headlineSmall?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: AppSpacing.sm),
                    ShopTag(name: shopName),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.md),
          isWide
              ? Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(flex: 3, child: emailLabel),
                    const SizedBox(width: AppSpacing.sm),
                    Expanded(flex: 3, child: phoneLabel),
                    const SizedBox(width: AppSpacing.sm),
                    Expanded(flex: 2, child: cityLabel),
                  ],
                )
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    emailLabel,
                    phoneLabel,
                    cityLabel,
                  ],
                ),
        ],
      ),
    );
  }
}