import 'package:flutter/material.dart';
import 'package:profile_penjual/core/constants/app_breakpoints.dart';
import 'package:profile_penjual/core/constants/app_spacing.dart';
import 'package:profile_penjual/models/product.dart';
import 'package:profile_penjual/widgets/product/product_card.dart';

class ProductGrid extends StatelessWidget {
  final List<Product> products;
  final String ecoLabel;

  const ProductGrid({
    super.key,
    required this.products,
    required this.ecoLabel,
  });

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.sizeOf(context).width;
    final isWide = screenWidth >= AppBreakpoints.wide;

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      padding: const EdgeInsets.all(AppSpacing.lg),
      itemCount: products.length,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: isWide ? 3 : 2,
        mainAxisSpacing: AppSpacing.md,
        crossAxisSpacing: AppSpacing.md,
        mainAxisExtent: 290,
      ),
      itemBuilder: (context, index) {
        final product = products[index];
        return ProductCard(
          imagePath: product.imagePath,
          name: product.name,
          price: product.price,
          ecoLabel: ecoLabel,
          isEcoFriendly: product.isEcoFriendly,
        );
      },
    );
  }
}