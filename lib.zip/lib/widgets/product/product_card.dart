import 'package:flutter/material.dart';
import 'package:profile_penjual/core/constants/app_spacing.dart';
import 'package:profile_penjual/widgets/common/eco_badge.dart';
import 'package:profile_penjual/widgets/product/product_image.dart';
import 'package:profile_penjual/widgets/product/product_info.dart';

class ProductCard extends StatelessWidget {
  final String imagePath;
  final String name;
  final String price;
  final String ecoLabel;
  final bool isEcoFriendly;
  final double? width;

  const ProductCard({
    super.key,
    required this.imagePath,
    required this.name,
    required this.price,
    required this.ecoLabel,
    this.isEcoFriendly = true,
    this.width,
  });

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;

    return Container(
      width: width,
      padding: const EdgeInsets.all(AppSpacing.sm),
      decoration: BoxDecoration(
        color: colors.surfaceContainerLowest,
        borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ProductImage(
            imagePath: imagePath,
            width: double.infinity,
            height: 130,
          ),
          ProductInfo(name: name, price: price),
          if (isEcoFriendly) EcoBadge(label: ecoLabel),
        ],
      ),
    );
  }
}